package com.me.mygdxgame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.OverlayLayout;

import jogo.Jogo;

public class teste extends JFrame implements KeyListener{
	

boolean showTitleScreen;
Main m;
public teste()
{ 
super("Jogos");
JPanel panel = new JPanel();
LayoutManager overlay = new OverlayLayout(panel);
panel.setLayout(overlay);
JLabel label1 = new JLabel("Clique A para jogo 1 ou S para jogo2");
label1.setForeground(Color.RED);
label1.setFont(new Font("Market", Font.BOLD, 30));
label1.setAlignmentX(0.5f);
label1.setAlignmentY(0.5f);
panel.add(label1);

JLabel label2 = 
new JLabel(new ImageIcon("C:\\flappy\\background.jpg"));                   
label2.setAlignmentX(0.5f);
label2.setAlignmentY(0.5f);
panel.add(label2);


add(panel);
pack();

setLayout(new FlowLayout());


 addKeyListener(this);
  setMinimumSize(new Dimension(600, 600));
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setVisible(true);
    setFocusable(true);
    setFocusTraversalKeysEnabled(false);
   
}
public static void main (String[] args) {		
 
            new teste ();
      
      
 }




public void keyPressed(KeyEvent e){
	int keyCode = e.getKeyCode();
	if(keyCode == KeyEvent.VK_A){
		this.setVisible(false);
		this.dispose();
		Main m = new Main();
		m.begin();		
	}
	if(keyCode == KeyEvent.VK_S){
		this.setVisible(false);
		this.dispose();
		Jogo j = new Jogo();
		 j.begin();
	}
	if(keyCode == KeyEvent.VK_R){
		this.setVisible(false);
		this.dispose();
		Jogo j = new Jogo();
		 j.begin();
	}

}
public void keyReleased(KeyEvent e){

e.consume();
}
public void keyTyped(KeyEvent e){
e.consume();
}




}
